<?php
namespace System;

/**
* 	@author Ammar Faizi <ammarfaizi2@gmail.com>
*/
class ActionHandler
{
    public function __construct()
    {
    }
}
