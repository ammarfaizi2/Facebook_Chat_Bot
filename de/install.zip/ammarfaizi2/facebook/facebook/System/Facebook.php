<?php
namespace System;

defined('fb_data') or die('fb_data is not defined !');

use Curl\CMCurl;
use System\Action\Comment;
use System\Action\Reaction;
use System\Action\GetMessages;

/**
*   @author Ammar Faizi <ammarfaizi2@gmail.com>
*   @package ammarfaizi2/facebook
*   @license RedAngel PHP Concept
*/
class Facebook
{
    const FB_URL = 'https://m.facebook.com';
    private $email;
    private $password;
    private $user;
    private $token;
    public $usercookies;
    use Comment,Reaction,GetMessages;

    private $curl_info;

    /**
    *   @param  *email (string)
    *   @param  *pass  (string)
    *   @param  user   (string)
    *   @param  token  (string)
    */
    public function __construct($email, $pass, $user=null, $token=null)
    {
        $this->email = $email;
        $this->password = $pass;
        if ($user===null) {
            $email = explode("@", $email);
            $this->user = $email[0];
        } else {
            if (preg_match("#[^\w\d\_\.]#", $user)) {
                throw new \Exception("Error username !", 1);
            }
            $this->user = $user;
        }
        is_dir(fb_data) or mkdir(fb_data);
        is_dir(fb_data.DIRECTORY_SEPARATOR.'cookies') or mkdir(fb_data.DIRECTORY_SEPARATOR.'cookies');
        $this->usercookies = fb_data.DIRECTORY_SEPARATOR.'cookies'.DIRECTORY_SEPARATOR.$this->user.'.txt';
        file_exists($this->usercookies) or file_put_contents($this->usercookies, '');
    }

    /**
    *   void
    *   @param socks (string)
    *   @param mode (int)
    */
    public function set_socks($socks, $mode=1)
    {
        if ($mode==1) {
            $this->socks = $socks;
        } else {
            unset($this->socks);
        }
    }

    /**
    *   @param to (string)
    *   @param post `mixed` (string|array[string])
    *   @param op (array)
    *   @return (string)
    */
    public function get_page($to, $post=null, $op=null)
    {
        $st = new CMCurl(((substr($to, 0, 8)=="https://" or substr($to, 0, 7)=="http://")? $to : self::FB_URL.'/'.$to));
        $st->set_cookie($this->usercookies);
        $st->set_useragent("Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:46.0) Gecko/20100101 Firefox/46.0");
        if (isset($this->socks)) {
            $st->set_socks($this->socks);
        }
        if (isset($post)) {
            $st->set_post($post);
        }
        if (isset($op)) {
            if (!is_array($op)) {
                throw new \Exception("Error get_page options", 1);
            }
            $st->set_optional($op);
        }
        $out = $st->execute();
        $inf = $st->get_info();
        $ern = $st->errno();
        $err = ((bool) $ern ? $ern.' : '.$st->error() : null) and $out = $err;
        $st->close();
        if (isset($inf['redirect_url']) and !empty($inf['redirect_url'])) {
            $out = $this->get_page($inf['redirect_url'], null, array(CURLOPT_REFERER=>$inf['url']));
        }
        $this->curl_info = $inf;
        return $out;
    }

    /**
    *   @return (string)
    */
    public function login()
    {
        $a = $this->get_page('');
        $p = '';
        $a = explode('<form', $a, 2);
        $a = explode('</form>', $a[1], 2);

        /* Ambil URL action */
        $action = explode('action="', $a[0], 2);
        $action = explode('"', $action[1], 2);
        $action = html_entity_decode($action[0], ENT_QUOTES, 'UTF-8');

        /* Ambil submit */
        $submit = explode('type="submit', $a[0], 2);
        $submit = explode('value="', $submit[0]);
        $submit = explode('"', end($submit), 2);
        $submit = trim(html_entity_decode($submit[0], ENT_QUOTES, 'UTF-8'));

        /* Pecah input form */
        $b = explode('type="hidden"', $a[0]);
        for ($i=1; $i < count($b); $i++) {

            /* Ambil name */
            $c = explode('name="', $b[$i], 2);
            $c = explode('"', $c[1], 2);

            /* Ambil value */
            $d = explode('value="', $b[$i], 2);
            $d = explode('"', $d[1], 2);

            $c[0]!='_fb_noscript' and
            $p.= urlencode(html_entity_decode($c[0], ENT_QUOTES, 'UTF-8')).'='.urlencode(html_entity_decode($d[0], ENT_QUOTES, 'UTF-8')).'&';
        }
        $p .= 'email='.urlencode($this->email).'&pass='.urlencode($this->password).'&login='.urlencode($submit);
        return $this->get_page($action, $p,
            array(
                CURLOPT_REFERER     =>  self::FB_URL,
                CURLOPT_HTTPHEADER  =>  array(
                        "Accept-Language: en-US,en;q=0.5",
                        "Accept-Encoding: gzip, deflate, br",
                        "Content-Length: ".strlen($p),
                        "Content-Type: application/x-www-form-urlencoded",
                    )
                )
            );
    }

    /**
    *   @return (string)
    */
    public function send_message($messages, $to, $stpr=null, $source=null)
    {
        if ($source===null) {
            $source = $this->get_page("https://m.facebook.com/".$to);
        } else {
            $source = $source;
        }
        $q = explode('action="/messages/send/', $source);
        $q = explode('</form>', $q[1]);
        $a = explode('<input type="hidden"', $q[0]);
        $postfields = array();
        for ($i=1;$i<count($a);$i++) {
            $b = explode(">", $a[$i]);
            $c = explode('name="', $b[0]);
            $d = explode('"', $c[1]);
            $e = explode('value="', $a[$i]);
            $f = isset($e[1]) ? explode('"', $e[1]) : array("","");
            $postfields[$d[0]] = $f[0];
        }
        $action = explode('"', $q[0]);
        $action = $action[0];
        $source=$q=$a=$b=$c=$d=$e=$f=null;
        if ($stpr===null) {
            $postfields['body'] = empty($messages)?"~":$messages;
            $postfields['Send'] = 'Kirim';
            $rt = null;
        } else {
            $postfields['send_photo'] = true;
            $rt = "curl_getinfo";
        }
        return $this->get_page("https://m.facebook.com/messages/send/?".$action, $postfields);
    }
    public function upload_photo($photo, $caption, $to, $src=null)
    {
        $a = $this->send_message(null, $to, true, $src);
        $a = explode('enctype="multipart/form-data">', $a);
        $a = explode('<input type="', $a[1]);
        for ($i=1;$i<count($a);$i++) {
            if (substr($a[$i], 0, 4)!="file") {
                $b = explode('name="', $a[$i]);
                $b = explode('"', $b[1]);
                $c = explode('value="', $a[$i]);
                $c = explode('"', $c[1]);
                $postfields[$b[0]] = $c[0];
            }
        }
        if (function_exists('curl_file_create')) {
            $cFile = curl_file_create($photo);
        } else {
            $cFile = '@'.realpath($photo);
        }
        $postfields['body'] = $caption;
        $postfields['file1'] = $cFile;
        return $this->get_page("https://upload.facebook.com/_mupload_/mbasic/messages/attachment/photo/", $this->cookies, $postfields, array(52=>false));
    }
}