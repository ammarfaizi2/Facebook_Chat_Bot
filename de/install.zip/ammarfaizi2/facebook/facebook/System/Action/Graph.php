<?php
namespace System;

/**
*
*/
class Graph
{
    public function __construct($token)
    {
        $this->token = $token;
    }
}
