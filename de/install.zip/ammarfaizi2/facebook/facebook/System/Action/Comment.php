<?php
namespace System\Action;

trait Comment
{
    public function comment($post_id, $text='~')
    {
        $a = explode('<form', $this->get_page(((substr($post_id, 0, 8)=="https://" or substr($post_id, 0, 7)=="http://") ? $post_id : self::FB_URL.'/'.$post_id), null, null), 2);
        $a = explode('</form', $a[1], 2);
        $p = '';
        $action = explode('action="', $a[0], 2);
        $action = explode('"', $action[1], 2);
        $action = substr(html_entity_decode($action[0], ENT_QUOTES, 'UTF-8'), 1);

        $a = explode('type="hidden"', $a[0]);
        for ($i=1; $i < count($a); $i++) {
            $b = explode('name="', $a[$i], 2);
            $b = explode('"', $b[1], 2);
            $c = explode('value="', $a[$i], 2);
            $c = explode('"', $c[1], 2);
            $p.= urlencode(html_entity_decode($b[0], ENT_QUOTES, 'UTF-8')).'='.urlencode(html_entity_decode($c[0], ENT_QUOTES, 'UTF-8')).'&';
        }
        $p.= 'comment_text='.urlencode($text);
        return $this->get_page($action, $p, array(CURLOPT_REFERER=>$this->curl_info['url']));
    }
}
