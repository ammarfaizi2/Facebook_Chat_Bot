<?php
require __DIR__ . '/vendor/autoload.php';
define('fb_data', __DIR__ . '/fb_data');
is_dir(fb_data) or mkdir(fb_data);

use System\Facebook;
header('Content-type: text/plain');
$user    = "ammarfaizi2";
$email    = "$user";
$pass    = "";
$token    = "";

$fb = new Facebook($email, $pass, $user, $token);
#print $fb->login();
foreach(Facebook::grb($fb->get_messages()) as $link => $qwe){
	$a = $fb->get_page($qwe);
	$fb->send_message("aa",null,null,$a);
	$b = Facebook::grchat($a);
	print_r($b);
	break;
}
#print $fb->reaction('https://m.facebook.com/1731151743581146','LOVE');
#print $fb->comment('https://m.facebook.com/1731151743581146','TDD KLENG');
/**
*
*	Debugging
*
*/
die;
// LIKE,LOVE,HAHA,WOW,SAD,ANGRY
header('Content-type: text/plain');
$a = file_get_contents('a.tmp');