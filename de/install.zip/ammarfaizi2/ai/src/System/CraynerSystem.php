<?php
namespace System;

/**
* @author Ammar Faizi <ammarfaizi2@gmail.com> https://www.facebook.com/ammarfaizi2
* @license RedAngel PHP Concept
*/

class CraynerSystem
{
    public function __construct()
    {
    }
}
