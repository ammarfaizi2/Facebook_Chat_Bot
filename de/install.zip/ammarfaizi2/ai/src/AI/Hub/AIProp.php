<?php

namespace AI\Hub;

interface AIProp
{
}
