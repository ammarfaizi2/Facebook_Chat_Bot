<?php
namespace AI;

use AI\CraynerSystem;
use AI\Hub\Singleton;

/**
 * @author Ammar Faizi <ammarfaizi2@gmail.com>
 */

class CraynerMachine extends CraynerSystem
{
    use Singleton;
    public function __construct()
    {
    }
}
