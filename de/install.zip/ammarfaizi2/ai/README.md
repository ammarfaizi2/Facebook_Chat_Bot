# Crayner AI

##	No Documentation

### Installation

Add `composer.json`

```json
{
    "require": {
        "ammarfaizi2/ai": "2.0"
    }
}

```